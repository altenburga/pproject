P-Project of Sarah Roediger (s1411241) and Danique Sessink (s1726374)

Installation.
You will have to unzip the package an place it in an directory.
Now you have the files at the following location:
[source directory]\ss\week8\qwirkle\
Open a command prompt at your source directory and compile the
server part of the program using:
javac ss\week8\qwirkle\game\Server.java
Now compile the client part of the program using (first open a new command prompt):
javac ss\week8\qwirkle\game\Client.java
You can now run the files using:
java ss.week8.qwirkle.game.Server [portnumber]  and
java ss.week8.qwirkle.game.Client [ip-adres portnumber]
e.g. localhost 1337 (for a client)
You need more than one client for the game, so you will need to open
several command prompts in your source directory and compile and run the client file.

Execution.

EDIT: we have pre-defined the joinrequest and gamerequest commands for you. now a game
with 2 clients will be played (if you open 2 client command windows).

Else you would have to do this:
Send a joinrequest like this in a client command prompt:
joinrequest name 0 0 0 0
You will receive the command "acceptrequest name 0 0 0 0" back.
Then, you can send a gamerequest like this:
gamerequest 2
This means you want to play a game with two players. You can choose between 2, 3, 4 or
nothing. If you just type in "gamerequest", you will be put in a reservelist, waiting to be
put in a playlist that is in need of one more player.
Once you've sent the gamerequests for all of the clients, you can play a game.


If you get the command "moverequest", it means that it's your turn. You can either move
or trade. The following goes for move:
setmove amount type color x y
Like: setmove 1 1 1 0 0
For multiple moves: setmove 3 1 1 0 0 | 1 2 0 1 | 1 3 0 2
First tile ALWAYS has to be placed on 0,0 (x=0 and y=0).
This goes for trade:
givestones amount type color
Like: givestones 1 1 1
For multiple trades: givestones 3 1 1 | 4 5 | 6 6

Have fun playing the game!