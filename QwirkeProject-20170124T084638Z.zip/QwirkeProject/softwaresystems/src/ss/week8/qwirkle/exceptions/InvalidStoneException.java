package ss.week8.qwirkle.exceptions;

public class InvalidStoneException extends NoLegalMoveException {

	public InvalidStoneException() {
		
	}
	public String getMessage() {
		return "Stone does not have right color and/or type";
	}

}