package ss.week8.qwirkle.exceptions;

public class LackOfResourceException extends WrongArgumentException {

	public LackOfResourceException() {
	}
	public String getMessage() {
		return "You do not have this stone";
	}

}