package ss.week8.qwirkle.exceptions;

public class NoLegalMoveException extends WrongArgumentException {

	public NoLegalMoveException() {
		
	}
	public String getMessage() {
		return "Your move is not legal";
	}

}