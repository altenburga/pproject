package ss.week8.qwirkle.exceptions;

public class NoLegalNameException extends WrongArgumentException {

	public NoLegalNameException() {
	}
	public String getMessage() {
		return "Your name may not contain whitespace or pipes";
	}

}
