package ss.week8.qwirkle.exceptions;

public class WrongArgumentException extends Exception {

	public WrongArgumentException() {
	}
	
	public String getMessage() {
		return "Wrong argument was used";
	}

}