package ss.week8.qwirkle.exceptions;

public class WrongNumberOfArgumentsException extends WrongArgumentException {

	public WrongNumberOfArgumentsException() {
	}
	
	public String getMessage() {
		return "you have used too few or too many arguments";
	}

}
