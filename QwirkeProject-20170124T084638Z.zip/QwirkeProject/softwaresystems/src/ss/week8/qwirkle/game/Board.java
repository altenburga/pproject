package ss.week8.qwirkle.game;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import ss.week8.qwirkle.exceptions.NoLegalMoveException;

public class Board {
	
	// -- instance Variables -------------------------------------------
	
	/*@ private invariant board != null; */
	/** 
	 * The board.
	 */
	private Map<Integer, Map<Integer, Stone>> board;
	

	// -- Constructor --------------------------------------------------
	
	public Board() {
		board = new HashMap<Integer, Map<Integer, Stone>>();
	}

	// -- Methods -----------------------------------------------------
	
	/**
	 * Makes a deep copy of the board.
	 * 
	 * @return a copy of the current board
	 */
	/*@ ensures \result != this;
  	*/
	public Board deepCopy() {
		Board result = new Board();
		for (Integer x : board.keySet()) {
			for (Integer y : board.get(x).keySet()) {
				Stone s = board.get(x).get(y);
			    result.placeStone(s, x, y);
			}
			
		}
		return result;
	}

	/**
	 * Checks if move is legal
	 * @param stone
	 * 				the stone that needs to be checked
	 * @param x
	 * 				the x-coordinate
	 * @param y
	 * 				the y-coordinate
	 * @return true if move is legal
	 * @throws NoLegalMoveException if the move is not legal
	 */
	/*@ requires stone != null;	
	 */
	public boolean checkMove(Stone stone, int x, int y) throws NoLegalMoveException {
		Stone top = getStone(x, y - 1);
        Stone bottom = getStone(x, y + 1);
        Stone left = getStone(x - 1, y);
        Stone right = getStone(x + 1, y);
        
        boolean isHorizontalValid = false;
        boolean isVerticalValid = false;
        
        //if stone is the first stone and 0,0 is empty
        if (top == null && bottom == null && left == null && right == null && x == 0
        										&& y == 0 && getStone(0, 0) == null) {
            return true;
        }
        
        // It should be next to another stone
        if (top == null && bottom == null && left == null && right == null) {
            return false;
        }
        
        //horizontal check
        int lx = x - 1;
        while (getStone(lx, y) != null) { 
        	lx = lx - 1;
        }
        lx++; //first place with stone
        
        List<Integer> types = new ArrayList<Integer>();
    	List<Integer> colors = new ArrayList<Integer>();
    	List<Integer> typesD = new ArrayList<Integer>();
    	List<Integer> colorsD = new ArrayList<Integer>();
        for (int i = lx; getStone(i, y) != null || i == x; i++) {
        	if (i == x) {
        		typesD.add(stone.getNumberType());
        		colorsD.add(stone.getNumberColor());
        		if (!types.contains(stone.getNumberType())) {
  	        		types.add(stone.getNumberType());
	  	        }
	  	       	if (!colors.contains(stone.getNumberColor())) {
	  	        	colors.add(stone.getNumberColor());
	  	        }
        	} else {
	        	typesD.add(getStone(i, y).getNumberType());
	        	colorsD.add(getStone(i, y).getNumberColor());
	        	if (!types.contains(getStone(i, y).getNumberType())) {
	        		types.add(getStone(i, y).getNumberType());
	        	}
	        	if (!colors.contains(getStone(i, y).getNumberColor())) {
	        		colors.add(getStone(i, y).getNumberColor());
	        	}
        	}
        }
        
        if (types.size() == 1 && colors.size() == colorsD.size() ||
        						colors.size() == 1 && types.size() == typesD.size()) {
        	isHorizontalValid = true;
        }
        
        //vertical check
        int ly = y - 1;
        while (getStone(x, ly) != null) {
        	ly = ly - 1;
        }
        ly++;
        
        List<Integer> typesY = new ArrayList<Integer>();
    	List<Integer> colorsY = new ArrayList<Integer>();
    	List<Integer> typesDY = new ArrayList<Integer>();
    	List<Integer> colorsDY = new ArrayList<Integer>();
        for (int i = ly; getStone(x, i) != null || i == y; i++) {
        	if (i == y) {
        		typesDY.add(stone.getNumberType());
        		colorsDY.add(stone.getNumberColor());
        		if (!typesY.contains(stone.getNumberType())) {
    	        	typesY.add(stone.getNumberType());
  	  	        }
  	  	       	if (!colorsY.contains(stone.getNumberColor())) {
  	  	        	colorsY.add(stone.getNumberColor());
  	  	        }
        	} else {
	        	typesDY.add(getStone(x, i).getNumberType());
	        	colorsDY.add(getStone(x, i).getNumberColor());
	        	if (!typesY.contains(getStone(x, i).getNumberType())) {
	        		typesY.add(getStone(x, i).getNumberType());
	        	}
	        	if (!colorsY.contains(getStone(x, i).getNumberColor())) {
	        		colorsY.add(getStone(x, i).getNumberColor());
	        	}
        	}
        }
        
        if (typesY.size() == 1 && colorsY.size() == colorsDY.size() ||
        							colorsY.size() == 1 && typesY.size() == typesDY.size()) {
        	isVerticalValid = true;
        }
        
		if (isHorizontalValid && isVerticalValid) {
			return true;
		}
		
		throw new NoLegalMoveException();
	}
	
	/*@ requires stone != null;
	 */
	/**
	 * Checks if a move for the computerPlayer is legal.
	 * @param stone
	 * 				the stone the player wants to move
	 * @param x
	 * 				the x-coordinate
	 * @param y
	 * 				the y-coordinate
	 * @return true if move is legal.
	 */
	public boolean checkMoveComputer(Stone stone, int x, int y) {
		Stone top = getStone(x, y - 1);
        Stone bottom = getStone(x, y + 1);
        Stone left = getStone(x - 1, y);
        Stone right = getStone(x + 1, y);
        
        boolean isHorizontalValid = false;
        boolean isVerticalValid = false;
        
        //if stone is the first stone and 0,0 is empty
        if (top == null && bottom == null && left == null && right == null && x == 0
        										&& y == 0 && getStone(0, 0) == null) {
            return true;
        }
        
        // It should be next to another stone
        if (top == null && bottom == null && left == null && right == null) {
            return false;
        }
        
        //horizontal check
        int lx = x - 1;
        while (getStone(lx, y) != null) { 
        	lx = lx - 1;
        }
        lx++; //first place with stone
        
        List<Integer> types = new ArrayList<Integer>();
    	List<Integer> colors = new ArrayList<Integer>();
    	List<Integer> typesD = new ArrayList<Integer>();
    	List<Integer> colorsD = new ArrayList<Integer>();
        for (int i = lx; getStone(i, y) != null || i == x; i++) {
        	if (i == x) {
        		typesD.add(stone.getNumberType());
        		colorsD.add(stone.getNumberColor());
        		if (!types.contains(stone.getNumberType())) {
  	        		types.add(stone.getNumberType());
	  	        }
	  	       	if (!colors.contains(stone.getNumberColor())) {
	  	        	colors.add(stone.getNumberColor());
	  	        }
        	} else {
	        	typesD.add(getStone(i, y).getNumberType());
	        	colorsD.add(getStone(i, y).getNumberColor());
	        	if (!types.contains(getStone(i, y).getNumberType())) {
	        		types.add(getStone(i, y).getNumberType());
	        	}
	        	if (!colors.contains(getStone(i, y).getNumberColor())) {
	        		colors.add(getStone(i, y).getNumberColor());
	        	}
        	}
        }
        
        if (types.size() == 1 && colors.size() == colorsD.size() ||
        						colors.size() == 1 && types.size() == typesD.size()) {
        	isHorizontalValid = true;
        }
        
        //vertical check
        int ly = y - 1;
        while (getStone(x, ly) != null) {
        	ly = ly - 1;
        }
        ly++;
        
        List<Integer> typesY = new ArrayList<Integer>();
    	List<Integer> colorsY = new ArrayList<Integer>();
    	List<Integer> typesDY = new ArrayList<Integer>();
    	List<Integer> colorsDY = new ArrayList<Integer>();
        for (int i = ly; getStone(x, i) != null || i == y; i++) {
        	if (i == y) {
        		typesDY.add(stone.getNumberType());
        		colorsDY.add(stone.getNumberColor());
        		if (!typesY.contains(stone.getNumberType())) {
    	        	typesY.add(stone.getNumberType());
  	  	        }
  	  	       	if (!colorsY.contains(stone.getNumberColor())) {
  	  	        	colorsY.add(stone.getNumberColor());
  	  	        }
        	} else {
	        	typesDY.add(getStone(x, i).getNumberType());
	        	colorsDY.add(getStone(x, i).getNumberColor());
	        	if (!typesY.contains(getStone(x, i).getNumberType())) {
	        		typesY.add(getStone(x, i).getNumberType());
	        	}
	        	if (!colorsY.contains(getStone(x, i).getNumberColor())) {
	        		colorsY.add(getStone(x, i).getNumberColor());
	        	}
        	}
        }
        
        if (typesY.size() == 1 && colorsY.size() == colorsDY.size() ||
        							colorsY.size() == 1 && typesY.size() == typesDY.size()) {
        	isVerticalValid = true;
        }
        
		if (isHorizontalValid && isVerticalValid) {
			return true;
		}
		
		return false;
	}

	
	
	
	/**
	 * Places stone on board
	 */
	/*@ requires stone != null;
	 */
	public void placeStone(Stone stone, int x, int y) {
		try {
			if (checkMove(stone, x, y)) {
				if (!board.containsKey(x)) {
					Map<Integer, Stone> yMap = new HashMap<Integer, Stone>();
					yMap.put(y, stone);
					board.put(x, yMap);
				} else {
					if (!board.get(x).containsKey(y) || board.get(x).get(y) == null) {
						Map<Integer, Stone> yMap = board.get(x);
						yMap.put(y, stone);
						board.put(x, yMap);
					}
				}
			}
		} catch (NoLegalMoveException e) {
			System.out.println(e.getMessage());
		}
		
	}
	
	/**
	 * Returns stone on position x,y.
	 * @param x
	 * @param y
	 * @return stone on position x, y
	 */
	public Stone getStone(int x, int y) {
		if (!board.containsKey(x)) {
			return null;
		} else {
			if (board.get(x).containsKey(y) && board.get(x).get(y) != null) {
				return board.get(x).get(y);
			} else {
				return null;
			}
		}
	}
	
	/**
	 * @return smallest value of x of the keyset of board
	 */
	public int xMin() {
		int minValue = 0;
		for (Integer x : board.keySet()) {
	        if (x < minValue) {
	            minValue = x;
	        }
	    }
	    return minValue;
	}
	
	/**
	 * @return biggest value of x of the keyset of board
	 */
	public int xMax() {
		int maxValue = 0;
		for (Integer x : board.keySet()) {
			if (x > maxValue) {
				maxValue = x;
			}
		}
		return maxValue;
	}
	
	/**
	 * @return smallest value of y of the values of board
	 */
	public int yMin() {
		int minValue = 0;
		for (Map<Integer, Stone> x : board.values()) {
			for (Integer y : x.keySet()) {
				if (y < minValue) {
					minValue = y;
				}
			}
		}
		return minValue;
	}
	
	/**
	 * @return biggest value of y of the values of board
	 */
	public int yMax() {
		int maxValue = 0;
		for (Map<Integer, Stone> x : board.values()) {
			for (Integer y : x.keySet()) {
				if (y > maxValue) {
					maxValue = y;
				}
			}
		}
		return maxValue;
	}

	/**
	 * Checks if the board is empty.
	 * 
	 * @return true
	 */
	public boolean isEmpty() {
		return !board.containsKey(0);
	}

	/**
	 * Resets (clears) the board.
	 */
	public void reset() {
		board.clear();
	}
	
	

}
