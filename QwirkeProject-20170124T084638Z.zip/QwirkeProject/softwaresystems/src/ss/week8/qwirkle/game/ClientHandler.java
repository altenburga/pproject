package ss.week8.qwirkle.game;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Map;

import ss.week8.qwirkle.exceptions.WrongArgumentException;
import ss.week8.qwirkle.exceptions.WrongNumberOfArgumentsException;

import java.util.HashMap;
import java.util.List;

public class ClientHandler extends Thread {
    private Server server;
    private BufferedReader in;
    private BufferedWriter out;
    private String clientName;
    private int status;
    private List<Stone> stones;
    private Map<Integer, Map<Integer, Stone>> move;
    private boolean moveHandled = false;
    private boolean tradeHandled = false;
    private int amountTrade = 0;
    private int amountMove = 0;
    private String moved;

    /**
     * Constructs a ClientHandler object
     * Initialises both Data streams.
     */
    //@ requires serverArg != null && sockArg != null;
    public ClientHandler(Server serverArg, Socket sockArg) throws IOException {
        this.server = serverArg;
        this.in = new BufferedReader(new InputStreamReader(sockArg.getInputStream()));
        this.out = new BufferedWriter(new OutputStreamWriter(sockArg.getOutputStream()));
        
        
    }
    
    /**
     * Returns a readable form of the clientName.
     */
    public String toString() {
    	return clientName;
    }
    
    /**
     * This method handles the input of the Client.
     * @param input
     * 				command the client wants to execute
     * @throws WrongArgumentException
     * 				if the client uses the wrong commands
     */
    public void inputHandler(String input) throws WrongArgumentException {
   		String[] lines = input.split(" ");
   		if (lines[0].equals("computerplayer")) {
   			handleComputerPlayer();
   		}
       	if (lines[0].equals("joinrequest")) {
       		if (lines.length != 6) { 
       			this.shutdown();
       		} else {
       			handleJoinRequest(lines);
       		}
       	} else if (lines[0].equals("gamerequest")) {
       		handleGameRequest(lines);
       	} else if (lines[0].equals("setmove")) {
       		moved = "";
       		try {
				handleSetmove(lines);
			} catch (WrongNumberOfArgumentsException e) {
				System.out.println("invalidcommand " + e.getMessage());
			}
       		for (int i = 2; i < lines.length; i++) {
       			moved += lines[i] + " ";
       		}
       	} else if (lines[0].equals("givestones")) {
       		handleTrade(lines);
       	} else {
       		throw new WrongArgumentException();
       	}
   	}
    
    public void handleComputerPlayer() {
    	System.out.println("joinrequest cp 0 0 0 0");
    	System.out.println("gamerequest");
    	//determinemove ophalen
    	System.out.println("" + "");
    }
    
    /**
     * Handles a joinrequest from the Client.
     * @param lines
     * 				the input from the Client.
     */
    public void handleJoinRequest(String[] lines) {
    	clientName = lines[1];
    	sendMessage("acceptrequest " + lines[1] + " " + lines[2] +
    			  " " + lines[3] + " " + lines[4] + " " + lines[5]);
    }
    
    /**
     * Handles a gameRequest from the Client.
     * @param lines
     * 				the input from the client.
     */
    /*@ requires lines != null;
     */
    public void handleGameRequest(String[] lines) {
    	if (lines[1] == null) {
    		status = 1;
    		server.addToPlayList(this);
    	} else {
    		int amount = Integer.valueOf(lines[1]);
    		if (amount >= 2 && amount <= 4) {
    			status = amount;
    			server.addToPlayList(this);
    		}
    	}
    	
    }
    
    /**
     * Handles a move the Client wants to do.
     * @param lines
     * 				the input from the Client.
     * @throws WrongNumberOfArgumentsException
     * 				if the Client uses too many or too few arguments.
     */
    /*@ requires lines != null;
     	ensures Integer.valueOf(lines[1]) == getMove().size();
     */
    public void handleSetmove(String[] lines) throws WrongNumberOfArgumentsException {
    	if (move != null) {
    		move.clear();
    	}
    	move = new HashMap<Integer, Map<Integer, Stone>>();
    	amountMove = Integer.valueOf(lines[1]);
		if (lines.length == amountMove * 5 + 1) {
			for (int i = 0; i < amountMove; i++) {
				int t = Integer.valueOf(lines[2 + i * 5]);
				int c = Integer.valueOf(lines[3 + i * 5]);
				int x = Integer.valueOf(lines[4 + i * 5]);
				int y = Integer.valueOf(lines[5 + i * 5]);
				Stone stone = new Stone(c, t);
				Stone tstone = transformStonesBack(stone);
				Map<Integer, Stone> yMap = new HashMap<Integer, Stone>();
				yMap.put(y, tstone);
				move.put(x, yMap);
			}
		} else {
			throw new WrongNumberOfArgumentsException();
		}
		moveHandled = true;
    }
    
    /**
     * Handles a trade from a Client.
     * @param lines
     * 				the input from the Client.
     * @throws WrongNumberOfArgumentsException
     * 				if the Client uses too many or too few arguments.
     * @throws WrongArgumentException
     * 				if the Client uses a wrong argument.
     */
    public void handleTrade(String[] lines) throws WrongNumberOfArgumentsException,
    														WrongArgumentException {
    	if (Integer.valueOf(lines[1]) != null) {
    		amountTrade = Integer.valueOf(lines[1]);
    	} else {
    		throw new WrongArgumentException();
    	}
    	stones = new ArrayList<Stone>();
    	if (lines.length == amountTrade * 3 + 1) {
			for (int i = 0; i < amountTrade; i++) {
				int t = Integer.valueOf(lines[2 + i * 3]);
				int c = Integer.valueOf(lines[3 + i * 3]);
				Stone stone = new Stone(c, t);
				Stone tstone = transformStonesBack(stone);
				stones.add(tstone);
			}
    	} else {
    		throw new WrongNumberOfArgumentsException();
    	}
    	tradeHandled = true;
    	
    }
    
    /**
     * Returns the status of a Client.
     * @return status of Client.
     */
    /*@ ensures \result >= 1 && \result <= 4; */
    /*@ pure */ public int getStatus() {
    	return status;
    }
    
    /**
     * Makes sure tradeHandled en moveHandled are false.
     */
    /*@ ensures tradeHandled() == false && moveHandled() == false;
     */
    public void handled() {
    	tradeHandled = false;
    	moveHandled = false;
    }
    
    /**
     * Returns the stones.
     * @return the stones.
     */
    /*@ pure */ public List<Stone> getStones() {
    	return stones;
    }
    
    /**
     * A method who returns the move a Client made.
     * @return the move that was made by a Client.
     */
    /*@ pure */public Map<Integer, Map<Integer, Stone>> getMove() {
    	return move;
    	
    }
    
    /**
     * Returns the to be traded stones.
     * @return the list of stones who need to be traded for a Client.
     */
    public List<Stone> getTrade() {
    	return stones;
    }
    
    /**
     * Transforms the stones from integers (int type, int color) to a readable
     * form of a stone for our ServerGame (Color color, Type type).
     * @param stone
     * 				the stone who needs to be transformed
     * @return the transformed stone.
     */
    public Stone transformStonesBack(Stone stone) {
		Stone.Color c = stone.getColor();
		Stone.Type t = stone.getType();
		Stone s = new Stone(c, t);
		return s;
	}
    
    /**
     * @return true if the move was handled (translated)
     */
    /*@ pure */ public boolean moveHandled() {
    	return moveHandled;
    }
    
    /**
     * @return true if the trade was handled
     */
    /*@ pure */ public boolean tradeHandled() {
    	return tradeHandled;
    }
    
    /**
     * @return how many stones were traded
     */
    /*@ pure */ public int getAmountTrade() {
    	return amountTrade;
    }
    
    /**
     * @return how many stones were moved
     */
    /*@ pure */ public int getAmountMove() {
    	return amountMove;
    }
    
    /**
     * @return what move was made (type color x y)
     */
    /*@ pure */ public String getMoved() {
    	return moved;
    }

    /**
     * This method takes care of receiving commands from the Client.
     * Every message that is received, is offered to the inputHandler
     * for executing it's command. If an IOException is thrown while reading
     * the message, the method concludes that the socket connection is
     * broken and shutdown() will be called. 
     */
    public void run() {
        try {
        	while (true) {
        		String sendLine = in.readLine();
        		try {
					inputHandler(sendLine);
				} catch (WrongArgumentException e) {
					System.out.println("invalidcommand " + e.getMessage());
				}
        	}
        } catch (IOException e) {
        	System.out.println("Shutting down");
        	shutdown();
        }
    }

    /**
     * This method can be used to send a message over the socket
     * connection to the Client. If the writing of a message fails,
     * the method concludes that the socket connection has been lost
     * and shutdown() is called.
     */
    public void sendMessage(String msg) {
        try {
        	out.write(msg);
        	out.newLine();
        	out.flush();
        } catch (IOException e) {
        	System.out.println("Shut down client");
        	shutdown();
        }
    }

    /**
     * This ClientHandler signs off from the Server and subsequently
     * sends a last broadcast to the Server to inform that the Client
     * is no longer participating in the game. 
     */
    private void shutdown() {
        server.removeHandler(this);
        server.broadcast("connectionlost " + clientName);
    }

	
}
