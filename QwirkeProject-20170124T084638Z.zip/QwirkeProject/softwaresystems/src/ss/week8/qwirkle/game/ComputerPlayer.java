package ss.week8.qwirkle.game;

import ss.week8.qwirkle.exceptions.NoLegalNameException;

public class ComputerPlayer extends Player {
	
	private String name;
	
	public ComputerPlayer(String name, ClientHandler clientHandler) throws NoLegalNameException {
		super(name, clientHandler);
	}
	
	/**
	 * @return name of the Player.
	 */
	public String getName() {
		return name;
	}
	
	/*public String determineMove(Board board) {

		Map<Player, List<Stone>> playerStones = getPlayerStones();
		String move = null;
		String choice = null;
		int aantal = 0;
		System.out.println("playerstones: " + playerStones);
		System.out.println("getname " + getName());
		List<Stone> stones = playerStones.get(getName());
		for(int x = board.xMin(); x < board.xMax(); x++) {
			for(int y = board.yMin(); y < board.yMax(); y++) {
				Stone stone = board.getStone(x, y);
				//this is for testing, not entirely smart yet
				if(stones.contains(stone.getNumberType()) &&
							!stones.contains(stone.getNumberColor()) ||
									!stones.contains(stone.getNumberType()) &&
											stones.contains(stone.getNumberColor())) {
					// checken of omgeving van stone op board vrij is
					aantal = 1; // Alleen voor het testen, moet nog veranderd worden
					choice = "move";
					Stone top = board.getStone(x,y-1);
			        Stone bottom = board.getStone(x,y+1);
			        Stone left = board.getStone(x-1,y);
			        Stone right = board.getStone(x+1,y);
					try {
						if(top == null && board.checkMove(stone, x, y-1)) {
							board.placeStone(stone, x, y-1);
						} else if(bottom == null && board.checkMove(stone, x, y+1)) {
							board.placeStone(stone, x, y+1);
						} else if(left == null && board.checkMove(stone, x-1, y)) {
							board.placeStone(stone, x-1, y);
						} else if(right == null && board.checkMove(stone, x+1, y)) {
							board.placeStone(stone, x+1, y);	
						} else if(top == null && bottom == null && left == null && right == null
												&& x == 0 && y == 0 && board.getStone(0, 0)==null) {
							board.placeStone(stone, 0, 0);
						}
					} catch (NoLegalMoveException e) {
						System.out.println(e.getMessage());
					}
					move = choice + " " + aantal + " " + stone.getNumberColor() + " " +
														stone.getNumberType() + " " + x + " " + y;
				} else {
					choice = "trade";
					move = choice + " " + aantal + " " + stone.getNumberColor() + " " +
																			stone.getNumberType();
					//trade(name,stones.get(0));
				}	
			}

		}
		return move;
	}*/
}
