package ss.week8.qwirkle.game;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import ss.week8.qwirkle.exceptions.LackOfResourceException;
import ss.week8.qwirkle.exceptions.NoLegalMoveException;
import ss.week8.qwirkle.exceptions.WrongArgumentException;
import ss.week8.qwirkle.exceptions.WrongNumberOfArgumentsException;
import ss.week8.qwirkle.game.Stone.Color;
import ss.week8.qwirkle.game.Stone.Type;

public class Game {

	//houdt speler objecten bij
	
	// -- Instance variables -----------------------------------------
	
	/*@ private invariant board != null; */
	/** 
	 * The board.
	 */
	private Board board;
	
	/*@
    private invariant (\forall int i; 0 <= i && i < players.length; players[i] != null); 
	*/
	/**
	 * The players of the game.
	 */
	private Player[] players;
	
	/*@
    private invariant playerStones.size() == players.length;
    private invariant (\forall Player p; p != null);
    private invariant (\forall Player p; 0 <= playerStones.get(p).size() &&
    															playerStones.get(p).size() <= 6);
	*/
	/**
	 * The players and a list of their stones.
	 */
	private Map<Player, List<Stone>> playerStones;
	
	/*@
    private invariant getCurrentPlayer() != null;
	*/
	/**
	 * The player whose turn it is.
	 */
	private Player currentPlayer;
	
	/*@
    private invariant (\forall Player p; 0 <= skippedPlayers.size() &&
    													skippedPlayers.size() <= players.length);
	*/
	/**
	 * The players who have been skipped during their turn because they could not move or trade.
	 */
	private List<Player> skippedPlayers = null;
	
	/*@
    private invariant (\forall Stone s; 0 <= stoneBag.size() && stoneBag.size() <= 108);
	*/
	/**
	 * The bag with the remaining stones.
	 */
	private List<Stone> stoneBag;
	
	/*@
    private invariant scores.size() == players.length;
    private invariant (\forall Player p; 0 <= scores.size() &&
    											scores.size() < players.length;
    												scores.get(p) <= 0); 
	*/
	/**
	 * The map of players with their score.
	 */
	private Map<Player, Integer> scores;
	
	/*@
    private invariant playedStonesCoordinates.size() >= 0 && playedStonesCoordinates.size() <= 108;
	*/
	/**
	 * The map of the already played stones on the board with their coordinates.
	 */
	private Map<Integer, Map<Integer, Integer>> playedStonesCoordinates;
	
	/*@
	 private invariant 0 <= current  && current < 4;
	 */
	/**
	 * Index of the current player.
	 */
	private int current;
	
	/**
	 * Number of players in the Qwirkle game.
	 */
	public int numberplayers;
	
	/**
	 * Score for a whole row or column of 6 stones of the same type
	 * and other color or the same color and other type.
	 */
	public static final int QWIRKLE = 6;
	
	private View view;
	
	
	// -- Constructors -----------------------------------------------

	
	/*@
	 requires (\forall int i; 0 <= i && i < numberplayers; players[i] != null);
	 */
	
	/**
	 * Creates a new Game object.
	 * 
	 * @param players
	 * 					the list of players.
	 */
	public Game(Player[] players) {
		board = new Board();
		view = new View();
		this.players = players;
		stoneBag = new ArrayList<Stone>();
		createStoneBag();
		giveStones();
		scores = new HashMap<Player, Integer>();
		current = determineStartingPlayer();
		currentPlayer = players[current];
		numberplayers = players.length;

	}

	// -- Methoden -------------------------------------------------------
	/**
	 *  Returns the current player.
	 * 
	 * @return the player who's turn it is
	 */
	/*@	requires getCurrentPlayer() != null;*/
	/*@ pure*/ public Player getCurrentPlayer() {
		return players[current];
	}
	
	
	/*@ requires getCurrentPlayer() != null; */
	public void makeMove(Board board) throws WrongArgumentException {
		currentPlayer = getCurrentPlayer();
		if (!determineMove(board)) { //als geen move meer mogelijk is en je kan niet ruilen...
			if (skippedPlayers != null && !skippedPlayers.contains(currentPlayer)) {
				skippedPlayers.add(currentPlayer);
			}
			nextPlayer();
		}
		if (currentPlayer instanceof ComputerPlayer) {
			determineMove(board);
			System.out.println("hoi");
			updateScore();
			nextPlayer();
		}
		System.out.println("dit is de currentplayer: " + currentPlayer);
		String input = readString("Vul in wat u wilt doen: trade [aantal type color]," 
															+ " move[aantal type color x y]\n");
		String[] split = input.split(" ");
		if (split.length > 0) {
			if (split[0].equals("trade")) {
				int stones = Integer.parseInt(split[1]);
				if (split.length == stones * 2 + 2) {
					for (int i = 0; i < stones; i++) {
						Stone.Type t = Stone.Type.getById(split[2 + i * 2].charAt(0));
						Stone.Color c = Stone.Color.getById(split[3 + i * 2].charAt(0));
						Stone stone = new Stone(c, t);
						try {
							trade(currentPlayer, stone);
						} catch (WrongArgumentException e) {
							System.out.println(e.getMessage());
						}
					}
					nextPlayer();
				} else {
					throw new WrongNumberOfArgumentsException();
				}
			} else if (split[0].equals("move")) {			
				int stones = Integer.parseInt(split[1]);
				if (split.length == stones * 4 + 2) {
					playedStonesCoordinates = new HashMap<Integer, Map<Integer, Integer>>();
					for (int i = 0; i < stones; i++) {
						Stone.Type t = Stone.Type.getById(split[2 + i * 4].charAt(0));
						Stone.Color c = Stone.Color.getById(split[3 + i * 4].charAt(0));
						int x = Integer.parseInt(split[4 + i * 4]);
						int y = Integer.parseInt(split[5 + i * 4]);
						Stone stone = new Stone(c, t);
						board.placeStone(stone, x, y); //hier is al gecheckt if move is legal
						Map<Integer, Integer> xyMap = new HashMap<Integer, Integer>();
						xyMap.put(x, y);
						playedStonesCoordinates.put(i, xyMap);
						switchStones(currentPlayer, stone);
					}
					updateScore();
					playedStonesCoordinates.clear();
					if (skippedPlayers !=  null && skippedPlayers.contains(currentPlayer)) {
						for (int i = 0; i < skippedPlayers.size(); i++) {
							if (skippedPlayers.get(i).equals(currentPlayer)) {
								skippedPlayers.remove(i);
							}
						}
						
					}
					nextPlayer();
				} else {
					throw new WrongNumberOfArgumentsException();
				}
				
			} else {
				throw new WrongArgumentException();
			}
		}
	}
	
	/**
     * Writes a prompt to standard out and tries to read an String value from
     * standard in. This is repeated until an String value is entered.
     * 
     * @param prompt
     *            the question to prompt the user
     * @return the first String value which is entered by the user
     */
    private String readString(String prompt) {
        String value = null;
        boolean intRead = false;
        @SuppressWarnings("resource")
        Scanner line = new Scanner(System.in);
        do {
            System.out.print(prompt);
            try (Scanner scannerLine = new Scanner(line.nextLine());) {
                if (scannerLine.hasNextLine()) {
                    intRead = true;
                    value = scannerLine.nextLine();
                }
            }
        } while (!intRead);
        return value;
    }
	
    
    /**
     * Takes the given stone from the player, puts it in the stonebag,
     * and gives the player another stone from the stonebag.
     * @param player
     * 				the player who is currently trading
     * @param stone
     * 				the stone the player wants to trade
     * @throws WrongArgumentException
     * 				if the player tries to trade more stones than there are in the stonebag
     */
    /*@ requires getStoneBag().size() >= 1 && stone != null && player != null;
     	ensures getPlayerStones() != \old (getPlayerStones());
     */
	public void trade(Player player, Stone stone) throws WrongArgumentException {
		List<Stone> stones = playerStones.get(player);
		int b = 0;
		try {
			if (checkPlayerStone(player, stone)) {
				if (stoneBag.size() >= 1) { //je mag niet meer stenen ruilen dan er in de zak zitten
					Stone newStone = stoneBag.get(0);
					stoneBag.remove(0);
					stoneBag.add(stone);
					for (int i = 0; i < stones.size(); i++) {
						Stone s = stones.get(i);
						if (s.equalss(stone)) { //function of Stone
							b = i;
						}
					}
					stones.remove(b);
					stones.add(newStone);
				} else {
					throw new WrongArgumentException();
				}
			}
		} catch (LackOfResourceException e) {
			System.out.println(e.getMessage());
		}
	}
	
	/**
	 * Removes the stoned the player placed on the board from
	 * the player's stonelist, and gives the player back new stones.
	 * 
	 * @param player
	 * 				the player who does a move on the board
	 * @param stone
	 * 				the stone the player placed on the board
	 */
	/*@ requires stone != null && player != null;
	 
	 */
	public void switchStones(Player player, Stone stone) { 
		List<Stone> stones = playerStones.get(player);
		int index = 0; //index at which the stone has to be removed from the player's stones
		try {
			if (checkPlayerStone(player, stone)) {
				if (stoneBag.size() >= 1) {
					Stone newStone = stoneBag.get(0);
					stoneBag.remove(0);
					for (int i = 0; i < stones.size(); i++) {
						Stone s = stones.get(i);
						if (s.equalss(stone)) { //function of Stone
							index = i;
						}
					}
					stones.remove(index);
					stones.add(newStone);
				} else {
					for (int i = 0; i < stones.size(); i++) {
						Stone s = stones.get(i);
						if (s.equalss(stone)) { //function of Stone
							index = i;
						}
					}
					stones.remove(index);
				}
				
			}
		} catch (LackOfResourceException e) {
			System.out.println(e.getMessage());
		}
	}
	
	/*@ pure*/ public List<Stone> getStoneBag() {
		return stoneBag;
	}
	
	/*@ pure*/ public Map<Player, List<Stone>> getPlayerStones() {
		return playerStones;
	}
	
	/**
	 * Updates the view of the board, the playerStones and the size of the stoneBag.
	 */
	public void update() {
		System.out.println(view.toString(board));
		System.out.println(players[0] + " heeft: " + playerStones.get(players[0]));
    	System.out.println(players[1] + " heeft: " + playerStones.get(players[1]));
    	System.out.println("Er zitten nog " + stoneBag.size() + " stenen in de zak.");
	}
	

	/**
     * Starts the Qwirkle game. <br>
     * Asks after each ended game if the user want to continue. Continues until
     * the user does not want to play anymore.
     */
	public void startGame() {
		boolean doorgaan = true;
        while (doorgaan) {
            reset();
            play();
            doorgaan = readBoolean("\n> Play another time? (y/n)?", "y", "n");
        }
	}
	
	/**
     * Prints a question which can be answered by yes (true) or no (false).
     * After prompting the question on standard out, this method reads a String
     * from standard in and compares it to the parameters for yes and no. If the
     * user inputs a different value, the prompt is repeated and the method reads
     * input again.
     * 
     * @param prompt the question to print
     * @param yes
     *            the String corresponding to a yes answer
     * @param no
     *            the String corresponding to a no answer
     * @return true is the yes answer is typed, false if the no answer is typed
     */
    private boolean readBoolean(String prompt, String yes, String no) {
        String answer;
        do {
            System.out.print(prompt);
            try (Scanner in = new Scanner(System.in)) {
                answer = in.hasNextLine() ? in.nextLine() : null;
            }
        } while (answer == null || (!answer.equals(yes) && !answer.equals(no)));
        return answer.equals(yes);
    }
	
	/**
     * Plays the Qwirkle game. <br>
     * First the (still empty) board is shown. Then the game is played until it
     * is over. Players can make a move one after the other. After each move,
     * the changed game situation is printed.
     */
    private void play() {
    	update();
    	while (!gameOver()) {
    		try {
				makeMove(board);
			} catch (WrongArgumentException e) {
				System.out.println(e.getMessage());
			}
    		update();
    	}
    	printResult();
    }
    
	/**
     * Returns true if the game is over. The game is over when there is a winner.
     *
     * @return true if the game is over
     */
    //@ ensures \result == this.hasWinner();
    /*@pure*/ public boolean gameOver() {
        return hasWinner();
    }
    
    /**
     * Creates a stoneBag.
     */
    public void createStoneBag() {
    	stoneBag.clear();
    	for (int i = 0; i < 3; i++) {
	    	for (Color color : Color.values()) {
	    		for (Type type : Type.values()) {
	    			Stone stone = new Stone(color, type);
	    			stoneBag.add(stone);
	    		}
	    	}
    	}
    	Collections.shuffle(stoneBag);
    }
    
    
    /**
     * Gives 6 stones to each player.
     */
    /*@ requires getStoneBag() != null;
     	ensures (\forall Player p; getPlayerStones().get(p).size() == 6);
     */
    public void giveStones() {
    	playerStones = new HashMap<Player, List<Stone>>();
    	for (int i = 0; i < this.players.length; i++) {
    		List<Stone> stones = new ArrayList<Stone>();
    		stones.addAll(stoneBag.subList(0, 6)); //veranderd.... 6 nu ipv 5
    		stoneBag.removeAll(stones);
    		playerStones.put(players[i], stones);
    	}

    }
    
    /**
     * Checks if the player has a certain stone.
     * 
     * @param player
     * 				the player who wants to make a move or wants to trade
     * @param stone
     * 				the stone that needs to be checked
     * @return true 
     * 				if player has the stone
     * 
     * @throws LackOfResourceException
     * 				if the player does not have the stone
     */
    /*@ requires player != null && stone != null && getPlayerStones() != null;
     	ensures \result == true;
     */
    public boolean checkPlayerStone(Player player, Stone stone) throws LackOfResourceException {
    	List<Stone> stones = playerStones.get(player);
    	for (int i = 0; i < stones.size(); i++) {
    		Stone s = stones.get(i);
    		if (s.equalss(stone)) {
    			return true;
    		}
    	}
    	throw new LackOfResourceException();
    }
    
    /**
     * Determines the player who needs to start.
     * This player has the highest number of matching stones
     * (same color and different type or different color and same type).
     * 
     * @return index of the player who needs to start
     */
    /*@ requires getPlayerStones() != null;
     	ensures \result >= 0 && \result <= numberplayers;
     */
    public int determineStartingPlayer() {
    	Player beginPlayer = null;
    	int beginMax = 0;
    	for (Player p : playerStones.keySet()) {
    		Map<Color, Integer> colors = new HashMap<Color, Integer>();
    		Map<Type, Integer> types = new HashMap<Type, Integer>();
    		List<Stone> stones = playerStones.get(p);
    		for (int i = 0; i < stones.size(); i++) {
    			Stone s = stones.get(i);
    			if (colors.containsKey(s.getColor())) {
    				colors.put(s.getColor(), colors.get(s.getColor()) + 1);
    			} else {
    				colors.put(s.getColor(), 1);
    			}
    			if (types.containsKey(s.getType())) {
    				types.put(s.getType(), types.get(s.getType()) + 1);
    			} else {
    				types.put(s.getType(), 1);
    			}
    		}
    		int maxRow = 0;
    		for (Map.Entry<Color, Integer> c : colors.entrySet()) {
    			if (c.getValue() > maxRow) {
    				maxRow = c.getValue();
    			}
    		}
    		for (Map.Entry<Type, Integer> c : types.entrySet()) {
    			if (c.getValue() > maxRow) {
    				maxRow = c.getValue();
    			}
    		}
    		
    		if (maxRow > beginMax) {
    			beginMax = maxRow;
    			beginPlayer = p;
    		}
    	}
    	
    	for (int i = 0; i < players.length; i++) {
    		if (players[i].equals(beginPlayer)) {
    			return i;
    		}
    	}
    	return 0;
    }
	

    /**
     * Determines if the Game has a player who ended the game (true),
     * not necessarily the one with the highest score.
     * 
     * Gives player extra 6 points if he is the one to end the game.
     * 
     * @return true
     * 				if there is a player who does not have any stones anymore or
     * 									if none of the players can do a move anymore
     */
    /*@ ensures \result == (getPlayerStones().get(getCurrentPlayer()).isEmpty());
     */
	public boolean hasWinner() {
		if (playerStones.get(currentPlayer).isEmpty()) {
			scoreAtEnd();
			return true;
		} else if (skippedPlayers != null && skippedPlayers.size() == numberplayers) {
			return true;
		}
		return false;
	}
	
	/**
	 * Determines the winning player.
	 * 
	 * @return the player with the highest score
	 */
	//JML
	public Player isWinner() {
		int maxValue = 0;
		Player p = players[0];
		for (Player player : scores.keySet()) {
			int score = scores.get(player);
			if (score > maxValue) {
				p = player;
			}
		}
		return p;
	}
	
	/**
     * Resets the game. <br>
     * The board is emptied and current becomes 0 (to be decided who will be currentPlayer).
     */
    private void reset() {
        current = 0;
        board.reset();
    }
	
	/**
	 * Passes the turn to the next Player
	 */
    /*@ ensures getCurrentPlayer() != null; */
	public void nextPlayer() {
		current = (current + 1) % numberplayers;
		System.out.println(players[current] + " is nu aan de beurt.");
		currentPlayer = players[current];
	}
	
	/**
	 * Updates the score of the Players
	 */
	/*@ ensures getCurrentPlayer().getScore() != \old (getCurrentPlayer().getScore()); */
	public void updateScore() {
		int x = 0;
		int y = 0;
		int score = 0;
		if (scores.get(currentPlayer) != null) {
			score = scores.get(currentPlayer);
		} else {
			score = 0;
		}
		
		Map<Integer, Integer> coordinates = playedStonesCoordinates.get(0);
		for (Integer i : coordinates.keySet()) {
			x = i;
			for (Integer i2 : coordinates.values()) {
				y = i2;
			}
		}

		int lx = x - 1;
        while (board.getStone(lx, y) != null) { 
            lx = lx - 1;
        }
        lx++;
        List<Stone> resultH = new ArrayList<Stone>();
        for (int i = lx; board.getStone(i, y) != null || i == x; i++) {
        	resultH.add(board.getStone(i, y));
        }
        
        if (resultH.size() == QWIRKLE) {
        	score += 2 * QWIRKLE;
        } else if (resultH.size() != 1) {
        	score += resultH.size();
        }
        
        int ly = y - 1;
        while (board.getStone(x, ly) != null) { 
            ly = ly - 1;
        }
        ly++;
        List<Stone> resultV = new ArrayList<Stone>();
        for (int i = ly; board.getStone(x, i) != null || i == y; i++) {
        	resultV.add(board.getStone(x, i));
        }
		
        if (resultV.size() == QWIRKLE) {
        	score += 2 * QWIRKLE;
        } else if (resultV.size() != 1) {
        	score += resultV.size();
        }
        
        if (resultH.size() == 1 && resultV.size() == 1) { //voor 1 zet op 0,0
        	score += 1;
        }
		
        scores.put(currentPlayer, score);
        
		System.out.println("De score van " + currentPlayer + " is: " + score);
		
		
	}
	
	/**
	 * Adds the six extra points to the score of the player who ends the game.
	 */
	/*@ ensures getCurrentPlayer().getScore()== \old (getCurrentPlayer().getScore() + 6); */
	public void scoreAtEnd() {
		int score = scores.get(currentPlayer);
		score += 6;
		scores.put(currentPlayer, score);
	}
	
	/**
     * Prints the result of the last game. <br>
     */
    private void printResult() {
        if (hasWinner()) {
            Player winner = isWinner();
            System.out.println("Player " + winner.getName() +
            					" (score: " + scores.get(winner) + ") has won!");
        } else {
            System.out.println("Draw. There is no winner!");
        }
    }
    
    /**
     * Determines a possible move and returns true if there is a move (or trade) which can be made.
     * 
     * @param board
     * 				board on which the move is made
     * @return boolean
     * 				if there is a move possible
     */
    /*@ requires board != null && getPlayerStones() != null;
     */
    public boolean determineMove(Board board) {
		String move = null;
		String choice = null;
		boolean end = false;
		int aantal = 0;
		System.out.println("playerstones: " + playerStones);
		System.out.println("getname " + currentPlayer.getName());
		List<Stone> stones = playerStones.get(currentPlayer);
		if (board.isEmpty()) {
			board.placeStone(playerStones.get(currentPlayer).get(0), 0, 0);
			end = true;
		}
		for (int x = board.xMin(); x < board.xMax(); x++) {
			for (int y = board.yMin(); y < board.yMax(); y++) {
				Stone stone = board.getStone(x, y);
				//this is for testing, not entirely smart yet
				if (stones.contains(stone.getNumberType()) &&
								!stones.contains(stone.getNumberColor()) ||
											!stones.contains(stone.getNumberType()) &&
														stones.contains(stone.getNumberColor())) {
					// checken of omgeving van stone op board vrij is
					aantal = 1; // Alleen voor het testen, moet nog veranderd worden
					choice = "move";
					System.out.println("x " + x);
					System.out.println("y " + y);
					Stone top = board.getStone(x, y - 1);
			        Stone bottom = board.getStone(x, y + 1);
			        Stone left = board.getStone(x - 1, y);
			        Stone right = board.getStone(x + 1, y);
					try {
						if (top == null && board.checkMove(stone, x, y - 1)) {
							board.placeStone(stone, x, y - 1);
						} else if (bottom == null && board.checkMove(stone, x, y + 1)) {
							board.placeStone(stone, x, y + 1);
						} else if (left == null && board.checkMove(stone, x - 1, y)) {
							board.placeStone(stone, x - 1, y);
						} else if (right == null && board.checkMove(stone, x + 1, y)) {
							board.placeStone(stone, x + 1, y);	
						} else if (top == null && bottom == null && left == null &&
													right == null && x == 0 && y == 0 &&
																board.getStone(0, 0) == null) {
							board.placeStone(stone, 0, 0);
						}
					} catch (NoLegalMoveException e) {
						System.out.println(e.getMessage());
					}
					move = choice + " " + aantal + " " + stone.getNumberColor()
											+ " " + stone.getNumberType() + " " + x + " " + y;
				} else {
					choice = "trade";
					move = choice + " " + aantal + " " + stone.getNumberColor()
											+ " " + stone.getNumberType();
					//trade(name,stones.get(0));
				}	
			}

		}
		return end;
	}

}
