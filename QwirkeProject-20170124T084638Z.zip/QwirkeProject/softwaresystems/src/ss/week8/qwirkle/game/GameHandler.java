package ss.week8.qwirkle.game;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Observable;
import java.util.Observer;

import ss.week8.qwirkle.exceptions.NoLegalNameException;

public class GameHandler extends Thread implements Observer {

	private Player[] players;
	private List<ClientHandler> clienthandlers = new ArrayList<ClientHandler>();
	private ServerGame game;
	private View view;
	
	public GameHandler(List<ClientHandler> clienthandlers) {
		this.clienthandlers = clienthandlers;
		players = new Player[clienthandlers.size()];
		for (int i = 0; i < clienthandlers.size(); i++) {
			Player player = null;
			try {
				player = new HumanPlayer(clienthandlers.get(i).getName(), clienthandlers.get(i));
			} catch (NoLegalNameException e) {
				e.getMessage();
			}
			players[i] = player;
		}
	}
	
	
	/**
	 * Run function for the GameHandler. Starts a game and keeps the game going.
	 * Sends messages to Client (like moverequest).
	 */
	public void run() {
		game = new ServerGame(players);
		game.addObserver(this);	
		sendMessageStartGame();
		sendMessageGiveStones(transformStones());
		sendMessageMoveRequest(game.getCurrentPlayer());
		view = new View();
		/*for (int j = 0; j < clienthandlers.size(); j++) {
			clienthandlers.get(j).sendMessage(view.toString(game.getBoard()));
     	}*/
		
		while (!game.gameOver()) {
		 	if (game.getCurrentPlayer().getClientHandler().moveHandled()) {
		     	setMove();
		     	game.getCurrentPlayer().getClientHandler().handled();
		     	game.nextPlayer(); //nextplayer
		     	sendMessageMoveRequest(game.getCurrentPlayer());
			}
			if (game.getCurrentPlayer().getClientHandler().tradeHandled()) {
				trade();
				game.getCurrentPlayer().getClientHandler().handled();
				game.nextPlayer();
				sendMessageMoveRequest(game.getCurrentPlayer());
			}
		}
	}
	
	/**
	 * Transforms a list of stones from a player (Color color, Type type) into a
	 * readable list of stones for the player (int type, int color) for the protocol.
	 * @return list of readable stones.
	 */
	public HashMap<Player, ArrayList<Stone>> transformStones() { //van letter naar integer
		Map<Player, List<Stone>> playerStones = game.getPlayerStones();
		HashMap<Player, ArrayList<Stone>> newPlayerStones = new HashMap<Player, ArrayList<Stone>>();
		for (int i = 0; i < players.length; i++) {
			List<Stone> stones = playerStones.get(players[i]);
			ArrayList<Stone> newStones = new ArrayList<Stone>();
			for (Stone stone : stones) {
				int color = stone.getNumberColor();
				int type = stone.getNumberType();
				newStones.add(new Stone(type, color));
			}
			newPlayerStones.put(players[i], newStones);
		}
		return newPlayerStones;
	}
	
	/**
	 * Does a move on the board.
	 */
	public void setMove() {
		game.setMove(game.getBoard());
	}
	
	/**
	 * Does a trade in the game.
	 */
	public void trade() {
		game.doTrade();
	}
	
	/**
	 * Returns a ClientHandler of a certain player.
	 * @param player
	 * 				the player you want the ClientHandler from.
	 * @return the requested ClientHandler.
	 */
	public ClientHandler getClientHandler(Player player) {
		return player.getClientHandler();
	}
	
	//	sendMessages --------------------------------------------------
	
	/**
	 * Sends a message to all of the players that the game has started and
	 * which players participate (according to protocol).
	 */
	public void sendMessageStartGame() {
		int current = game.determineStartingPlayer();
		String message = "startgame ";
		for (int i = 0; i < players.length; i++) {
			message = message + players[current].getClientHandler().toString() + " ";
			current = (current + 1) % players.length;
			
		}
		for (int j = 0; j < clienthandlers.size(); j++) {
			clienthandlers.get(j).sendMessage(message);
		}
	}
	/**
	 * Sends a message to all players which stones they get at the beginning
	 * of the game.
	 * @param stoneMap
	 * 					stones the players get at the beginning of the game.
	 */
	public void sendMessageGiveStones(HashMap<Player, ArrayList<Stone>> stoneMap) {
		for (Player player : stoneMap.keySet()) {
			String message = "givestones 6 ";
			for (int i = 0; i < 6; i++) {
				Stone s = stoneMap.get(player).get(i);
				int t = s.getNumberType();
				int c = s.getNumberColor();
				message = message + t + " " + c + " | ";
			}
			String newMessage = message.substring(0, message.length() - 3);
			player.getClientHandler().sendMessage(newMessage);
		}
	}
	
	public void transformedStones(HashMap<Player, ArrayList<Stone>> stoneMap) {
		for (Player player : stoneMap.keySet()) {
			String message = "givestones 6 ";
			for (int i = 0; i < 6; i++) {
				Stone s = stoneMap.get(player).get(i);
				int t = s.getNumberType();
				int c = s.getNumberColor();
				message = message + t + " " + c + " | ";
			}
			String newMessage = message.substring(0, message.length() - 3);
			player.getClientHandler().sendMessage(newMessage);
		}
	}
	
	/**
	 * Sends a moverequest to the player which turn it is.
	 * @param player
	 * 				the player who needs to make a move.
	 */
	public void sendMessageMoveRequest(Player player) {
		player.getClientHandler().sendMessage("moverequest");
	}
	
	/**
	 * Update method for Observer pattern.
	 */
	@Override
	public void update(Observable arg0, Object arg1) {
		if (arg1.equals("trade")) {
			for (int i = 0; i < clienthandlers.size(); i++) {
				clienthandlers.get(i).sendMessage("notifytrade " +
						  game.getCurrentPlayer().getClientHandler().toString() +
						  " " + getClientHandler(game.getCurrentPlayer()).getAmountTrade());
			}		
			clienthandlers.get(game.getCurrent()).sendMessage("new PlayerStones: "
					  + game.getPlayerStones());
		} else if (arg1.equals("move")) {
			for (int j = 0; j < clienthandlers.size(); j++) {
				clienthandlers.get(j).sendMessage(("notifymove " +
					 	  game.getCurrentPlayer().getClientHandler().toString() +
						  " " + game.getCurrentScore() + " " +
						  getClientHandler(game.getCurrentPlayer()).getAmountMove()) +
						  " " + getClientHandler(game.getCurrentPlayer()).getMoved());
				if (clienthandlers.get(j).toString().equals("dani")) {
					clienthandlers.get(j).sendMessage(view.toString(game.getBoard()));
				}
				/*clienthandlers.get(j).sendMessage("current playerStones: "
						  + transformStones());
				clienthandlers.get(j).sendMessage(view.toString(game.getBoard()));
				transformedStones(transformStones());*/
				
			}
			/*System.out.println(view.toString(game.getBoard()));
			System.out.println("current playerStones: " + transformStones());*/
		}
	}

}
