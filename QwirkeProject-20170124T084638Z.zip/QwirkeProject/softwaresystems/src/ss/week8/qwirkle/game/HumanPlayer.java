package ss.week8.qwirkle.game;

import ss.week8.qwirkle.exceptions.NoLegalNameException;

public class HumanPlayer extends Player {

	public HumanPlayer(String name, ClientHandler clientHandler) throws NoLegalNameException {
		super(name, clientHandler);
	}

}
