package ss.week8.qwirkle.game;

import ss.week8.qwirkle.exceptions.NoLegalNameException;

public abstract class Player {

	// -- Instance variables -----------------------------------------
	
	private String name;
	private ClientHandler clientHandler;
	private int score;
	
	// -- Constructors -----------------------------------------------
    /*@ requires name != null;
		ensures this.getName() == name;
		ensures this.getClientHandler() == ch;
		ensures getScore() == 0;
	*/
	/**
	* Creates a new Player object.
	* 
	*/
	public Player(String name, ClientHandler ch) throws NoLegalNameException {
		if (name.contains("|")) {
			throw new NoLegalNameException();
		}
		this.name = name;
		this.clientHandler = ch;
		this.score = 0;
	}
			
	// -- Queries ----------------------------------------------------
	
	/**
	 * @return the name of a player
	 */
    /*@ pure */ public String getName() {
		return name;
	}
			
	/**
	 * @return the score of a player
	 */
	/*@ pure */ public int getScore() {
		return score;
	}

	/**
	 * @return a readable name of a player
	 */
	/*@ pure */ public String toString() {
		return name;
	}
	
	/**
	 * @return the ClientHandler of a player
	 */
	/*@ pure */ public ClientHandler getClientHandler() {
		return clientHandler;
	}

}
