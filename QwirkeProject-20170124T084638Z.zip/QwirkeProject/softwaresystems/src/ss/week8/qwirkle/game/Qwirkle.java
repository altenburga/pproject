package ss.week8.qwirkle.game;

import ss.week8.qwirkle.exceptions.NoLegalNameException;

public class Qwirkle {
	
	/**
	 * Class for playing the game locally (for testing as in: implementing the rules).
	 * You get to see the stones as: COLOR TYPE
	 * You need to fill in the commands as TYPE COLOR
	 * As in you have stone B S, you want to lay it on 0,0:
	 * move 1 S B 0 0
	 */
	
	public Qwirkle() {
		
	}
	
	public static void main(String[] args) {
		Player one = null;
		Player two = null;
		try {
			one = new HumanPlayer("sarah", null);
			two = new HumanPlayer("danique", null);
		} catch (NoLegalNameException e) {
			System.out.println(e.getMessage());
		}
		Player[] players = new Player[2];
		players[0] = one;
		players[1] = two;
		Game game = new Game(players);
		game.startGame();
	}

}
