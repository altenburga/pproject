package ss.week8.qwirkle.game;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class Server {
    private static final String USAGE
            = "usage: " + Server.class.getName() + " <port>";
    private ServerSocket serverSock;

    /** Start een Server-applicatie op. */
    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println(USAGE);
            System.exit(0);
        }
        
        Server server = null;
		try {
			server = new Server(Integer.parseInt(args[0]));
		} catch (NumberFormatException | IOException e) {
			e.printStackTrace();
		}
        server.run();
        
    }


    private List<ClientHandler> threads = new ArrayList<ClientHandler>();
    private Map<Integer, List<ClientHandler>> playList = new HashMap<Integer, 
    		  List<ClientHandler>>();
    
    /** Constructs a new Server object. */
    public Server(int portArg) throws IOException {
        serverSock = new ServerSocket(portArg);
        threads = new ArrayList<ClientHandler>();
        
    }
    
    /**
     * Listens to a port of this Server if there are any Clients that 
     * would like to connect. For every new socket connection a new
     * ClientHandler thread is started that takes care of the further
     * communication with the Client.
     */
    public void run() {
        System.out.println("Server started");
        while (true) {
        	try {
        		Socket sock = serverSock.accept();
        		System.out.println("New: " + sock.getInetAddress().toString() + ": " +
        				  sock.getPort());
        		addHandler(new ClientHandler(this, sock));
        	} catch (IOException e) {
        		e.printStackTrace();
        		System.out.println("Server terminated");
        		System.exit(0);
        	}
        }
    }
    
    /**
     * Adds a player to a playList with a status according to with how many
     * players he wants to play a Game.
     * @param clientHandler
     * 						the player (clientHandler) who needs to be added to a playList.
     */
    public void addToPlayList(ClientHandler clientHandler) {
    	if (playList.get(clientHandler.getStatus()) == null) {
    		for (int i = 1; i < 5; i++) {
    			playList.put(i, null);
    		}
    	}
    	List<ClientHandler> currentPlayList = new ArrayList<ClientHandler>();
    	if (playList.get(clientHandler.getStatus()) != null) {
    		currentPlayList = playList.get(clientHandler.getStatus());
    	}
    	currentPlayList.add(clientHandler);
    	playList.put(clientHandler.getStatus(), currentPlayList);
    	checkList(clientHandler.getStatus(), currentPlayList);
    }
    
    /**
     * Checks for a list if it is full, and if it is, prepares that list
     * for a game.
     * If there is a list who is in need of 1 player, the list with
     * players who don't care with how many players they want to play will be 
     * checked and if there is such a player, it will be put in the list
     * who is in need of another player and the game will be prepared for this
     * playList
     * @param status
     * 				with how many players a player wants to play
     * @param currentPlayList
     * 				playList who needs to be checked.
     */
    public void checkList(int status, List<ClientHandler> currentPlayList) {
    	if (status > 1) {
    		if (currentPlayList.size() == status) {
    			prepareGame(currentPlayList);
    			//playList.get(status).clear(); //delete currentPlayList from playList
    		} else {
    			if (currentPlayList.size() == status - 1) {
	    			if (playList.get(1) != null) {
	    				ClientHandler reserve = playList.get(1).get(0);
	    				currentPlayList.add(reserve);
	    				//playList.remove(reserve); //remove reserve player from playList
	    				prepareGame(currentPlayList);
	    				//playList.get(status).clear(); //delete currentPlayList from playList
	    			} 				
    			}
    		}
    	} else {
    		for (int i = 2; i <= 4; i++) {
    			if (playList.get(i).size() == i - 1) {
    				ClientHandler reserve = playList.get(1).get(0);
    				List<ClientHandler> temporaryPlayList = playList.get(i);
    		    	temporaryPlayList.add(reserve);
    		    	//playList.remove(reserve);
    		    	playList.put(i, temporaryPlayList);
    		    	prepareGame(temporaryPlayList);
    		    	//playList.get(i).clear(); //clear playList
    			}
    			
				
    		}
    	}
    	
    }
    
    /**
     * Prepares a game of Qwirkle for the players.
     * Starts a new GameHandler for these players.
     * @param players
     * 				the players who play this game with each other
     */
    public void prepareGame(List<ClientHandler> players) {
    	GameHandler gameHandler = new GameHandler(players);
    	gameHandler.start();
    }
    
    /**
     * Function who prints a message to System.out.
     * @param message
     * 				the message who needs to be printed to System.out
     */
    public void print(String message) {
        System.out.println(message);
    }
    
    /**
     * Sends a message using the collection of connected ClientHandlers
     * to all connected Clients.
     * @param msg message that is send
     */
    public synchronized void broadcast(String msg) {
    	for (ClientHandler c : threads) {
    		c.sendMessage(msg);
    	}
    }
    
    /**
     * Add a ClientHandler to the collection of ClientHandlers.
     * @param handler ClientHandler that will be added
     */
    public void addHandler(ClientHandler handler) {
    	threads.add(handler);
    	handler.start();
    }
    
    /**
     * Remove a ClientHandler from the collection of ClientHanlders. 
     * @param handler ClientHandler that will be removed
     */
    public void removeHandler(ClientHandler handler) {
    	threads.remove(handler);
    }
    
}

