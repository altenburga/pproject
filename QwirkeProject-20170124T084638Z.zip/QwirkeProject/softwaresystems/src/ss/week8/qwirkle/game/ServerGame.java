package ss.week8.qwirkle.game;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Observable;

import ss.week8.qwirkle.exceptions.LackOfResourceException;
import ss.week8.qwirkle.exceptions.NoLegalMoveException;
import ss.week8.qwirkle.exceptions.WrongArgumentException;
import ss.week8.qwirkle.game.Stone.Color;
import ss.week8.qwirkle.game.Stone.Type;

public class ServerGame extends Observable {
	
	// -- Instance variables -----------------------------------------
	
	/*@ private invariant board != null; */
	/** 
	 * The board.
	 */
	private Board board;
	
	/*@ private invariant (\forall int i; 2 <= i && i <= 4; players[i] != null); 
	*/
	/**
	 * The players of the game.
	 */
	private Player[] players;
	
	/*@
    private invariant playerStones.size() == players.length;
    private invariant (\forall Player p; p != null);
    private invariant (\forall Player p; 0 <= playerStones.get(p).size() &&
    	  playerStones.get(p).size() <= 6);
	*/
	/**
	 * The players and a list of their stones.
	 */
	private Map<Player, List<Stone>> playerStones;
	
	/*@
    private invariant getCurrentPlayer() != null;
	*/
	/**
	 * The player whose turn it is.
	 */
	private Player currentPlayer;
	
	/*@
    private invariant (\forall Player p; 0 <= skippedPlayers.size() &&
    	  skippedPlayers.size() <= players.length);
	*/
	/**
	 * The players who have been skipped during their turn because they could not move or trade.
	 */
	private List<Player> skippedPlayers = null;
	
	/*@
    private invariant (\forall Stone s; 0 <= stoneBag.size() && stoneBag.size() <= 108);
	*/
	/**
	 * The bag with the remaining stones.
	 */
	private List<Stone> stoneBag;
	
	/*@
    private invariant scores.size() == players.length;
    private invariant (\forall Player p; 0 <= scores.size() &&
    	  scores.size() < players.length; scores.get(p) <= 0); 
	*/
	/**
	 * The map of players with their score.
	 */
	private Map<Player, Integer> scores;
	
	/*@ private invariant currentScore >= 0;
	 */
	/**
	 * Current score of a player.
	 */
	private int currentScore;
	
	/*@
    private invariant playedStonesCoordinates.size() >= 0 && playedStonesCoordinates.size() <= 108;
	*/
	/**
	 * The map of the already played stones on the board with their coordinates.
	 */
	private Map<Integer, Map<Integer, Integer>> playedStonesCoordinates =
			  new HashMap<Integer, Map<Integer, Integer>>();
	
	/*@ private invariant 0 <= current  && current < players.length;
	 */
	/**
	 * Index of the current player.
	 */
	private int current;
	
	/*@ private invariant 2 <= players.length && players.length <= 4;*/
	/**
	 * Number of players in the Qwirkle game.
	 */
	public int numberplayers; 
	
	/**
	 * Score for a whole row or column of 6 stones of the same type
	 * and other color or the same color and other type.
	 */
	public static final int QWIRKLE = 6;
	
	
	// -- Constructors -----------------------------------------------

	
	/*@
	 requires (\forall int i; 0 <= i && i < numberplayers; players[i] != null);
	 */
	
	/**
	 * Creates a new Game object.
	 * 
	 * @param players
	 * 					the list of players.
	 */
	public ServerGame(Player[] players) {
		board = new Board();
		this.players = players;
		stoneBag = new ArrayList<Stone>(); 
		createStoneBag();
		giveStones();
		scores = new HashMap<Player, Integer>();
		current = determineStartingPlayer();
		currentPlayer = players[current];
		numberplayers = players.length;
	}

	// -- Methoden -------------------------------------------------------
	/**
	 *  Returns the current player.
	 * 
	 * @return the player who's turn it is
	 */
	/*@ requires getCurrentPlayer() != null;*/
	/*@ pure*/ public Player getCurrentPlayer() {
		return players[current];
	}
	
	/**
	 * Returns the board of the game.
	 * 
	 * @return the board
	 */
	public Board getBoard() {
		return board;
	}
	
	/**
	 * Function for trading one single stone.
	 * 
	 */
	/*@ requires getCurrentPlayer() != null;
	 	requires getCurrentPlayer().getClientHandler().getTrade() != null;
	 */
	public void doTrade() {
		currentPlayer = getCurrentPlayer();
		if (determinePossibleMove(board) == null) {
			if (skippedPlayers != null && !skippedPlayers.contains(currentPlayer)) {
				skippedPlayers.add(currentPlayer);
			}
			//nextPlayer();
		}
		if (currentPlayer instanceof ComputerPlayer) {
			determinePossibleMove(board); //nog fixen
			System.out.println("hoi");
			updateScore();
			//nextPlayer();
		}
		List<Stone> stones = currentPlayer.getClientHandler().getTrade();
		for (Stone s : stones) {
			Stone.Type t = s.getType();
			Stone.Color c = s.getColor();
			Stone stone = new Stone(c, t);
			try {
				trade(currentPlayer, stone);
			} catch (WrongArgumentException e) {
				e.getMessage();
			}
		}
		setChanged();
		notifyObservers("trade");
	}
	
	/**
	 * Does a move on the board.
	 * @param board
	 * 				the board the move is made on.
	 */
	public void setMove(Board board) {
		currentPlayer = getCurrentPlayer();
		if (determinePossibleMove(board) == null) {
			System.out.println("determine move niet gelukt");
			if (skippedPlayers != null && !skippedPlayers.contains(currentPlayer)) {
				skippedPlayers.add(currentPlayer);
				System.out.println("skippedPlayers was uitgevoerd.");
			}
		}
		if (currentPlayer instanceof ComputerPlayer) {
			determinePossibleMove(board); //nog fixen
			System.out.println("hoi");
			updateScore();
		}
		
		Map<Integer, Map<Integer, Stone>> move = currentPlayer.getClientHandler().getMove();
		int count = 0;
		for (Integer x : move.keySet()) {
			for (Integer y: move.get(x).keySet()) {
				Stone stone = move.get(x).get(y);
				board.placeStone(stone, x, y);
				Map<Integer, Integer> xyMap = new HashMap<Integer, Integer>();
				xyMap.put(x, y);
				playedStonesCoordinates.put(count, xyMap);
				count++;
				switchStones(currentPlayer, stone);
			}
		}	
		updateScore();
		playedStonesCoordinates.clear();
		if (skippedPlayers !=  null && skippedPlayers.contains(currentPlayer)) {
			skippedPlayers.clear();
		}
		
		setChanged();
		notifyObservers("move");
	}
	
    
    /**
     * Takes the given stone from the player, puts it in the stoneBag,
     * and gives the player another stone from the stoneBag.
     * @param player
     * 				the player who is currently trading
     * @param stone
     * 				the stone the player wants to trade
     * @throws WrongArgumentException
     * 				if the player tries to trade more stones than there are in the stoneBag
     */
    /*@ requires getStoneBag().size() >= 1 && stone != null && player != null;
     	ensures getPlayerStones() != \old (getPlayerStones());
     */
	public void trade(Player player, Stone stone) throws WrongArgumentException{ 
		List<Stone> stones = playerStones.get(player);
		int b = 0;
		try {
			if (checkPlayerStone(player, stone)) {
				if (stoneBag.size() >= 1) { //je mag niet meer stenen ruilen dan er in de zak zitten
					Stone newStone = stoneBag.get(0);
					stoneBag.remove(0);
					stoneBag.add(stone);
					for (int i = 0; i < stones.size(); i++) {
						Stone s = stones.get(i);
						if (s.equalss(stone)) { //function of Stone
							b = i;
						}
					}
					stones.remove(b);
					stones.add(newStone);
				} else {
					throw new WrongArgumentException();
				}
			}
		} catch (LackOfResourceException e) {
			System.out.println(e.getMessage());
		}
		setChanged();
		notifyObservers("trade");
	}
	
	/**
	 * Removes the stoned the player placed on the board from
	 * the player's stonelist, and gives the player back new stones.
	 * 
	 * @param player
	 * 				the player who does a move on the board
	 * @param stone
	 * 				the stone the player placed on the board
	 */
	/*@ requires stone != null && player != null;
	 
	 */
	public void switchStones(Player player, Stone stone) { 
		List<Stone> stones = playerStones.get(player);
		int index = 0; //index at which the stone has to be removed from the player's stones
		try {
			if (checkPlayerStone(player, stone)) {
				if (stoneBag.size() >= 1) {
					Stone newStone = stoneBag.get(0);
					stoneBag.remove(0);
					for (int i = 0; i < stones.size(); i++) {
						Stone s = stones.get(i);
						if (s.equalss(stone)) { //function of Stone
							index = i;
						}
					}
					stones.remove(index);
					stones.add(newStone);
				} else {
					for (int i = 0; i < stones.size(); i++) {
						Stone s = stones.get(i);
						if (s.equalss(stone)) { //function of Stone
							index = i;
						}
					}
					stones.remove(index);
				}
				
			}
		} catch (LackOfResourceException e) {
			System.out.println(e.getMessage());
		}
	}
	
	/**
	 * @return the stoneBag
	 */
	/*@ pure */ public List<Stone> getStoneBag() {
		return stoneBag;
	}
	
	/**
	 * @return the playerStones
	 */
	/*@ pure */ public Map<Player, List<Stone>> getPlayerStones() {
		return playerStones;
	}
	
	/**
	 * @return the coordinates of the placed stones.
	 */
	/*@ pure */ public Map<Integer, Map<Integer, Integer>> getPlayedStonesCoordinates() {
		return playedStonesCoordinates;
	}
    
	/**
     * Returns true if the game is over. The game is over when there is a winner.
     *
     * @return true if the game is over
     */
    //@ ensures \result == this.hasWinner();
    /*@pure*/ public boolean gameOver() {
        return hasWinner();
    }
    
    /**
     * Creates a stoneBag.
     */
    public void createStoneBag() {
    	stoneBag.clear();
    	for (int i = 0; i < 3; i++) {
	    	for (Color color : Color.values()) {
	    		for (Type type : Type.values()) {
	    			Stone stone = new Stone(color, type);
	    			stoneBag.add(stone);
	    		}
	    	}
    	}
    	Collections.shuffle(stoneBag);
    }
    
    
    /**
     * Gives 6 stones to each player.
     */
    /*@ requires getStoneBag() != null;
     	ensures (\forall Player p; getPlayerStones().get(p).size() == 6);
     */
    public void giveStones() {
    	playerStones = new HashMap<Player, List<Stone>>();
    	for (int i = 0; i < this.players.length; i++) {
    		List<Stone> stones = new ArrayList<Stone>();
    		stones.addAll(stoneBag.subList(0, 6));
    		stoneBag.removeAll(stones);
    		playerStones.put(players[i], stones);
    	}
    }
    
    /**
     * Checks if the player has a certain stone.
     * 
     * @param player
     * 				the player who wants to make a move or wants to trade
     * @param stone
     * 				the stone that needs to be checked
     * @return true 
     * 				if player has the stone
     * 
     * @throws LackOfResourceException
     * 				if the player does not have the stone
     */
    /*@ requires player != null && stone != null && getPlayerStones() != null;
     	ensures \result == true;
     */
    public boolean checkPlayerStone(Player player, Stone stone) throws LackOfResourceException {
    	List<Stone> stones = playerStones.get(player);
    	for (int i = 0; i < stones.size(); i++) {
    		Stone s = stones.get(i);
    		if (s.equalss(stone)) {
    			return true;
    		}
    	}
    	throw new LackOfResourceException();
    }
    
    /**
     * Determines the player who needs to start.
     * This player has the highest number of matching stones (same color
     * and different type or different color and same type).
     * 
     * @return index of the player who needs to start
     */
    /*@ requires getPlayerStones() != null;
     	ensures \result >= 0 && \result <= numberplayers;
     */
    public int determineStartingPlayer() {
    	Player beginPlayer = null;
    	int beginMax = 0;
    	for (Player p : playerStones.keySet()) {
    		Map<Color, Integer> colors = new HashMap<Color, Integer>();
    		Map<Type, Integer> types = new HashMap<Type, Integer>();
    		List<Stone> stones = playerStones.get(p);
    		for (int i = 0; i < stones.size(); i++) {
    			Stone s = stones.get(i);
    			if (colors.containsKey(s.getColor())) {
    				colors.put(s.getColor(), colors.get(s.getColor()) + 1);
    			} else {
    				colors.put(s.getColor(), 1);
    			}
    			if (types.containsKey(s.getType())) {
    				types.put(s.getType(), types.get(s.getType()) + 1);
    			} else {
    				types.put(s.getType(), 1);
    			}
    		}
    		int maxRow = 0;
    		for (Map.Entry<Color, Integer> c : colors.entrySet()) {
    			if (c.getValue() > maxRow) {
    				maxRow = c.getValue();
    			}
    		}
    		for (Map.Entry<Type, Integer> c : types.entrySet()) {
    			if (c.getValue() > maxRow) {
    				maxRow = c.getValue();
    			}
    		}
    		
    		if (maxRow > beginMax) {
    			beginMax = maxRow;
    			beginPlayer = p;
    		}
    	}
    	
    	for (int i = 0; i < players.length; i++) {
    		if (players[i].equals(beginPlayer)) {
    			return i;
    		}
    	}
    	return 0;
    }
	

    /**
     * Determines if the Game has a player who ended the game (true),
     * not necessarily the one with the highest score.
     * 
     * Gives player extra 6 points if he is the one to end the game.
     * 
     * @return true
     * 				if there is a player who does not have any stones anymore
     * 				or if none of the players can do a move anymore
     */
    /*@ ensures \result == (getPlayerStones().get(getCurrentPlayer()).isEmpty());
     */
	public boolean hasWinner() {
		if (playerStones.get(currentPlayer).isEmpty()) {
			scoreAtEnd();
			return true;
		} else if (skippedPlayers != null && skippedPlayers.size() == numberplayers) {
			return true;
		}
		return false;
	}
	
	/**
	 * Determines the winning player.
	 * 
	 * @return the player with the highest score
	 */
	//JML
	public Player isWinner() {
		int maxValue = 0;
		Player p = players[0];
		for (Player player : scores.keySet()) {
			int score = scores.get(player);
			if (score > maxValue) {
				p = player;
			}
		}
		return p;
	}
	
	/**
     * Resets the game. <br>
     * The board is emptied and current becomes 0 (to be decided who will be currentPlayer).
     */
    private void reset() {
        current = 0;
        board.reset();
    } //TODO : ergens gebruiken
    
	
	/**
	 * Passes the turn to the next Player
	 */
    /*@ ensures getCurrentPlayer() != null; */
	public void nextPlayer() {
		current = (current + 1) % numberplayers;
		System.out.println(players[current] + " is nu aan de beurt.");
		currentPlayer = players[current];
	}
	
	public int getCurrentScore() {
		return currentScore;
	}
	
	public int getCurrent() {
		return current;
	}
	
	/**
	 * Updates the score of the Players
	 */
	/*@ ensures getCurrentPlayer().getScore() != \old (getCurrentPlayer().getScore()); */
	public void updateScore() {
		int x = 0;
		int y = 0;
		int score = 0;
		currentScore = 0;
		int oldScore = 0;
		if (scores.get(currentPlayer) != null) {
			score = scores.get(currentPlayer);
			oldScore = scores.get(currentPlayer);
		} else {
			score = 0;
			oldScore = 0;
		}
		
		Map<Integer, Integer> coordinates = playedStonesCoordinates.get(0);
		for (Integer i : coordinates.keySet()) {
			x = i;
			for (Integer i2 : coordinates.values()) {
				y = i2;
			}
		}

		int lx = x - 1;
        while (board.getStone(lx, y) != null) { 
            lx = lx - 1;
        }
        lx++;
        List<Stone> resultH = new ArrayList<Stone>();
        for (int i = lx; board.getStone(i, y) != null || i == x; i++) {
        	resultH.add(board.getStone(i, y));
        }
        
        if (resultH.size() == QWIRKLE) {
        	score += 2 * QWIRKLE;
        } else if (resultH.size() != 1) {
        	score += resultH.size();
        }
        
        
        int ly = y - 1;
        while (board.getStone(x, ly) != null) { 
        	ly = ly - 1;
        }
        ly++;
        List<Stone> resultV = new ArrayList<Stone>();
        for (int i = ly; board.getStone(x, i) != null || i == y; i++) {
        	resultV.add(board.getStone(x, i));
        }
		
        if (resultV.size() == QWIRKLE) {
        	score += 2 * QWIRKLE;
        } else if (resultV.size() != 1) {
        	score += resultV.size();
        }
        
        if (resultH.size() == 1 && resultV.size() == 1) { //voor 1 zet op 0,0
        	score += 1;
        }
		
        scores.put(currentPlayer, score);
        
        currentScore = score - oldScore;
        
		System.out.println("De score van " + currentPlayer + " is: " + score);
		
		
	}
	
	/**
	 * Adds the six extra points to the score of the player who ends the game.
	 */
	/*@ ensures getCurrentPlayer().getScore()== \old (getCurrentPlayer().getScore() + 6); */
	public void scoreAtEnd() {
		int score = scores.get(currentPlayer);
		score += 6;
		scores.put(currentPlayer, score);
	}
	
	/**
     * Prints the result of the last game. <br>
     */
    private void printResult() {
        if (hasWinner()) {
            Player winner = isWinner();
            System.out.println("Player " + winner.getName() + " (score: " +
            		  scores.get(winner) + ") has won!");
        } else {
            System.out.println("Draw. There is no winner!");
        }
    } //TODO ergens gebruiken
    
    /**
     * Determines a possible move and returns a String if
     * there is a move (or trade) which can be made.
     * 
     * @param board
     * 				board on which the move is made
     * @return String
     * 				with a move possible
     */
    /*@ requires board != null && getPlayerStones() != null;
     */
    public String determinePossibleMove(Board board) {
    	String possibleMove = null;
    	Board result = board.deepCopy();
    	currentPlayer = getCurrentPlayer();
    	for (int i = 0; i < playerStones.get(currentPlayer).size(); i++) {
    		for (int x = result.xMin(); x <= result.xMax(); x++) {
    			for (int y = result.yMin(); y <= result.yMax(); y++) {
    				Stone stone = playerStones.get(currentPlayer).get(i);
    				if (result.checkMoveComputer(stone, x, y)) {
    					result.placeStone(stone, x, y);
    					possibleMove = "setmove 1 " + stone.getNumberType() + " " +
    							  stone.getNumberColor() + " " + x + " " + y;
    					return possibleMove;
    				}
    			}
    		}
    	}
    	if (stoneBag.size() >= 1) {
    		return "trade 1 " + playerStones.get(currentPlayer).get(0);
    	}
    	return null;
    }

}
