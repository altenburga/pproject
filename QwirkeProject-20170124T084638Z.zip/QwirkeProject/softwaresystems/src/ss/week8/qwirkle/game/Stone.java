package ss.week8.qwirkle.game;

public class Stone {

	// -- instance Variables -----------------------------------------------


	
	public enum Color {
	    RED(1, 'R'),
	    ORANGE(2, 'O'),
	    YELLOW(3, 'Y'),
	    GREEN(4, 'G'),
	    BLUE(5, 'B'),
	    PURPLE(6, 'P');
	    private int number;
	    private char id;
	    Color(int number, char id) {
	    	this.number = number;
	    	this.id = id;
	    }
		
		public int getNumber() {
			return this.number;
		}
		
		public char getId() {
			return id;
		}
		
		public static Color getById(char id) {
			for (Color t : values()) {
				if (t.getId() == id) {
					return t;
				}
			}
			return null;
		}
		
		public static Color getByInteger(int i) {
			for (Color t : values()) {
				if (t.getNumber() == i) {
					return t;
				}
			}
			return null;
		}
	}
	
	public enum Type {
	    CIRCLE(1, 'C'),
	    CROSS(2, 'X'),
	    DIAMOND(3, 'D'),
	    RECTANGLE(4, 'R'),
	    STAR(5, 'S'),
	    CLUBS(6, 'L');
	    private int number;
	    private char id;
	    Type(int number, char id) {
	    	this.number = number;
	    	this.id = id;
	    }
	    Type(int number) {
	    	this.number = number;
	    }
		
		public int getNumber() {
			return this.number;
		}
		
		public char getId() {
			return id;
		}
		
		public static Type getById(char id) {
			for (Type t : values()) {
				if (t.getId() == id) {
					return t;
				}
			}
			return null;
		}
		
		public static Type getByInteger(int i) {
			for (Type t : values()) {
				if (t.getNumber() == i) {
					return t;
				}
			}
			return null;
		}
	}


	private Type type;
	private Color color;
	
	// -- Constructor ----------------------------------------------------------
	
	public Stone(Color color, Type type) {
		this.type = type;
		this.color = color;
	}
	
	public Stone(int type, int color) {
		this.type = Stone.Type.getByInteger(type);
		this.color = Stone.Color.getByInteger(color);
	}
	

	// -- Methods ---------------------------------------------------------------

	public String toString() {
		return color.getId() + " " + type.getId();
	}
	
	
	
	public int getNumberColor() {
		return color.getNumber();
	}
	
	public int getNumberType() {
		return type.getNumber();
	}
	
	public Color getColor() {
		return color;
	}
	
	public Type getType() {
		return type;
	}
	
	public boolean equalss(Object s2) {
		if (!(s2 instanceof Stone)) {
			return false;
		}
		Stone stone = (Stone) s2;
		return this.getColor() == stone.getColor() && this.getType() == stone.getType();
	}
	
}
