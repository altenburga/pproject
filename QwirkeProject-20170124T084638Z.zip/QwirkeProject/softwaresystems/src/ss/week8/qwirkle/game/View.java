package ss.week8.qwirkle.game;

public class View {

	// -- instance Variables -----------------------------------------------
	
	// -- Constructor ------------------------------------------------------
	public View() {
	}
	// -- Methods ----------------------------------------------------------

	public String toString(Board board) {
        String output = "";
        for (int y = board.yMin() - 1; y <= board.yMax() + 1; y++) {
            for (int x = board.xMin() - 1; x <= board.xMax() + 1; x++) {
                Stone s = board.getStone(x, y);
                if (s != null && y < 0) {
                    output += "(" + s.toString() + ")   ";
                } else if (s != null) {
                	output += " (" + s.toString() + ")  ";
                } else {
                	if (x < 0 || y < 0) {
                		output += "[" + x + "," + y + "]  ";
                	} else if (x < 0 && y < 0) {
                		output += "[" + x + "," + y + "]";
                	} else {
                		output += " [" + x + "," + y + "]  ";
                	}
                }
            }
            output += System.lineSeparator();
        }
        return output;
    }

}
