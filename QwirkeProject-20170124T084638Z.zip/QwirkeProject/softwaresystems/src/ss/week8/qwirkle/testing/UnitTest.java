package ss.week8.qwirkle.testing;

import ss.week8.qwirkle.exceptions.LackOfResourceException;
import ss.week8.qwirkle.exceptions.NoLegalNameException;
import ss.week8.qwirkle.exceptions.WrongArgumentException;
import ss.week8.qwirkle.game.Board;
import ss.week8.qwirkle.game.ComputerPlayer;
import ss.week8.qwirkle.game.HumanPlayer;
import ss.week8.qwirkle.game.Player;
import ss.week8.qwirkle.game.ServerGame;
import ss.week8.qwirkle.game.Stone;
import ss.week8.qwirkle.game.Stone.Color;
import ss.week8.qwirkle.game.Stone.Type;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

public class UnitTest {

	/**
	 * This JUnit Test tests the Board class and the ServerGame class.
	 */
	
	private ServerGame game;
	private Player one;
	private Player two;
	@Before
	public void setUp() throws Exception {
		try {
			one = new HumanPlayer("sarah", null);
			two = new ComputerPlayer("danique", null);
		} catch (NoLegalNameException e) {
			System.out.println(e.getMessage());
		}
		Player[] players = new Player[2];
		players[0] = one;
		players[1] = two;
		game = new ServerGame(players);

	}

	/**
	 * Test to see if the startingPlayer is really the currentPlayer.
	 */
	@Test
	public void testCurrentPlayer() {
		int sp = game.determineStartingPlayer();
		int cp = game.getCurrent();
		assertEquals(sp, cp);
	}
	
	/**
	 * Test if each player got six stones after starting the game.
	 */
	@Test
	public void testGiveStones() {
		assertEquals(game.getPlayerStones().get(one).size(), 6);
		assertEquals(game.getPlayerStones().get(two).size(), 6);
		
	}
	
	/**
	 * Test to see if traded stones are not the same as old stones.
	 * There can be a rare case that they will be the same, but this
	 * would be a very rare case.
	 */
	@Test
	public void testTrade() {
		try {
			List<Stone> prevStone = new ArrayList<Stone>();
			List<Stone> prevStoneBag = new ArrayList<Stone>();
			for (Stone s : game.getPlayerStones().get(one)) {
				prevStone.add(s);
			}
			for (Stone s : game.getStoneBag()) {
				prevStoneBag.add(s);
			}
			for (int i = 0; i < game.getPlayerStones().get(one).size(); i++) {
				game.trade(one, game.getPlayerStones().get(one).get(i));
			}
			assertNotSame(game.getPlayerStones().get(one), prevStone);
			assertNotSame(prevStoneBag, game.getStoneBag());
		} catch (WrongArgumentException e) {
			System.out.println(e.getMessage());
		}
		
	}
	
	/**
	 * Test to see if a move was really placed on the Board.
	 */
	@Test
	public void testSetMove() {
		Map<Integer, Map<Integer, Stone>> move = new HashMap<Integer, Map<Integer, Stone>>();
		Map<Integer, Stone> yMap = new HashMap<Integer, Stone>();
		Stone s = game.getPlayerStones().get(one).get(0);
		yMap.put(0, s);
		move.put(0, yMap);
		for (Integer x : move.keySet()) {
			for (Integer y: move.get(x).keySet()) {
				Stone stone = move.get(x).get(y);
				game.getBoard().placeStone(stone, x, y);
				game.switchStones(one, stone);
				assertEquals(game.getBoard().getStone(0, 0), stone);
			}
		}
	}
	
	/**
	 * Test to see if creating the stoneBag really
	 * succeeded (including giving stones to two
	 * players afterwards).
	 */
	@Test
	public void testCreateStoneBag() {
		assertEquals(game.getStoneBag().size(), 96);
	}
	
	/**
	 * Test to see if the method checkPlayerStone really
	 * works.
	 */
	@Test
	public void testCheckPlayerStones() {
		try {
			for (int i = 0; i < game.getPlayerStones().get(one).size(); i++) {
				assertEquals(game.checkPlayerStone(one, game.getPlayerStones().get(one).get(i)),
						  true);
			}
		} catch (LackOfResourceException e) {
			System.out.println(e.getMessage());
		}
	}
	
	/**
	 * Test to see if the score is updated after making a move.
	 */
	@Test
	public void testScore() {
		Map<Integer, Map<Integer, Stone>> move = new HashMap<Integer, Map<Integer, Stone>>();
		Map<Integer, Stone> yMap = new HashMap<Integer, Stone>();
		Stone s = game.getPlayerStones().get(one).get(0);
		yMap.put(0, s);
		move.put(0, yMap);
		int count = 0;
		for (Integer x : move.keySet()) {
			for (Integer y: move.get(x).keySet()) {
				Stone stone = move.get(x).get(y);
				game.getBoard().placeStone(stone, x, y);
				game.switchStones(one, stone);
				Map<Integer, Integer> xyMap = new HashMap<Integer, Integer>();
				xyMap.put(x, y);
				game.getPlayedStonesCoordinates().put(count, xyMap);
				count++;
				game.updateScore();
				assertEquals(1, game.getCurrentScore());
			}
		}
	}
	
	/**
	 * Test to see if the deepCopy is really a copy of the
	 * current board.
	 */
	@Test
	public void testDeepCopy() {
		Board board = new Board();
		Stone stone = new Stone(Color.BLUE, Type.CIRCLE);
		board.placeStone(stone, 0, 0);
		Board result = board.deepCopy();
		assertSame(board.getStone(0, 0), result.getStone(0, 0));
	}
	
	/**
	 * Test to see if the board is really empty after using
	 * the reset function.
	 */
	@Test
	public void testReset() {
		Board board = new Board();
		Stone stone = new Stone(Color.BLUE, Type.CIRCLE);
		board.placeStone(stone, 0, 0);
		board.reset();
		assertTrue(board.isEmpty());
	}
	
	/**
	 * Test if the maximums and minimums of x and y are correct.
	 */
	@Test
	public void testMax() {
		Board board = new Board();
		Stone stone = new Stone(Color.BLUE, Type.CIRCLE);
		Stone stone2 = new Stone(Color.BLUE, Type.CLUBS);
		board.placeStone(stone, 0, 0);
		board.placeStone(stone2, 0, 1);
		board.placeStone(stone2, 1, 0);
		assertEquals(board.yMax(), 1);
		assertEquals(board.yMin(), 0);
		assertEquals(board.xMax(), 1);
		assertEquals(board.yMin(), 0);
	}

	
}
